package board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

public class BoardDAO {
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/myDB?useUnicode=true&characterEncoding=utf8&serverTimezone=UTC";
	private static final String USER ="root";
	private static final String PWD="root";
	
	public BoardDAO() {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(URL,USER,PWD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public int insertBoard(BoardDTO dto) {
		int ok =0;
		
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = "insert into board(title,name,pwd,content) values(?,?,?,?)";
		
		try {
			conn = getConnection();
			ps=conn.prepareStatement(sql);
			ps.setString(1,dto.getTitle());
			ps.setString(2,dto.getName());
			ps.setString(3,dto.getPwd());
			ps.setString(4,dto.getContent());
			
			ok = ps.executeUpdate(); 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close(conn,ps);
		}
		
		return ok;
	}
	//read
	public BoardDTO boardRead(int num) {
		BoardDTO dto = new BoardDTO();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = "SELECT NUM,TITLE,NAME,PWD,CONTENT,REGDATE,HIT FROM BOARD WHERE NUM=?";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				int n = rs.getInt("num");
				String title = rs.getString("title");
				String name = rs.getString("name");
				String pwd = rs.getString("pwd");
				String content = rs.getString("content");
				Date regdate = rs.getTimestamp("regdate");
				int hit = rs.getInt("hit");
				
				dto.setNum(n);
				dto.setTitle(title);
				dto.setName(name);
				dto.setPwd(pwd);
				dto.setContent(content);
				dto.setRegdate(regdate);
				dto.setHit(hit);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(conn,ps,rs);
		}
		return dto;
	}
	//조회수증가
	public void updateHit(int num) {
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = "update board set hit=hit+1 where num=?";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, num);
			ps.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			
		}
	}
	
	//update
	public int updateBoard(BoardDTO dto) {
		int ok =0;
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = "update board set title=?,name=?,content=? where num=? and pwd=?";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setString(1, dto.getTitle());
			ps.setString(2, dto.getName());
			ps.setString(3, dto.getContent());
			ps.setInt(4, dto.getNum());
			ps.setString(5, dto.getPwd());
			
			System.out.println(dto.getNum()+" "+dto.getPwd());
			ok = ps.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(conn,ps);
		}
		return ok;
	}
	//delete
	public int deleteBoard(BoardDTO dto) {
		int ok = 0;
		Connection conn = null;
		PreparedStatement ps = null;
		String sql = "delete from board where num=? and pwd=?";
		
		try {
			conn=getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dto.getNum());
			ps.setString(2, dto.getPwd());
			
			ok = ps.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			close(conn,ps);
		}
		
		return ok;
	}
	public int countBoard() {
		int cnt =0;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = "select count(*) from board";
		
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
	
			if(rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, ps, rs);
		}
		
		return cnt;
	}
	public ArrayList<BoardDTO> listBoard(int begin,int size) {
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
		String sql = "SELECT num,title,regdate,hit FROM board order by num desc limit ?,?";
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
	
		try {
			conn = getConnection();
			ps = conn.prepareStatement(sql);
			ps.setInt(1, begin);
			ps.setInt(2, size);
			
			rs = ps.executeQuery();
	
			while(rs.next()) {
				int num = rs.getInt("num");
				String title = rs.getString("title");
				Date regdate = rs.getDate("regdate");
				int hit = rs.getInt("hit");
	
				BoardDTO dto = new BoardDTO();
				dto.setNum(num);
				dto.setTitle(title);
				dto.setRegdate(regdate);
				dto.setHit(hit);
	
				list.add(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(conn, ps, rs);
		}
		
		return list;
	}
	private void close(Connection conn, PreparedStatement ps) {
		try {
			if(ps!=null) {
				ps.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(conn!=null) {
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void close(Connection conn, PreparedStatement ps, ResultSet rs){
		try {
			if(rs!=null) {
				rs.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(ps!=null) {
				ps.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(conn!=null) {
				conn.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
