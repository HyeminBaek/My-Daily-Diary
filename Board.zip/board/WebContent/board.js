$(function(){
	$("#btn_write").on('click',function(){
		if($("#title").val()==""){
			alert("input the title");
			$("#title").focus();
			return;
		}
		if($("#name").val()==""){
			alert("input the name");
			$("#name").focus();
			return;
		}
		if($("#pwd").val()==""){
			alert("input the password");
			$("#pwd").focus();
			return;
		}
		if($("#content").val()==""){
			alert("input the content");
			$("#content").focus();
			return;
		}
		$("#writeform").submit();
	});
	//amend and remove
	$("#btn_update").on('click',function(){
		//alert("btn_update click!");
		var num = $("#num").val();
		var pg= $("#pg").val();
		location.href = "updateform.jsp?num="+num+"&pg="+pg;
	});
	
	$("#btn_delete").on('click',function(){
		//alert("btn_update click!");
		var num = $("#num").val();
		var pg= $("#pg").val();
		location.href = "deleteform.jsp?num="+num+"&pg="+pg;
	});
	//update form
	$("#btn_amend").on('click',function(){
		if($("#title").val()==""){
			alert("input the title");
			$("#title").focus();
			return;
		}
		if($("#name").val()==""){
			alert("input the name");
			$("#name").focus();
			return;
		}
		if($("#pwd").val()==""){
			alert("input the password");
			$("#pwd").focus();
			return;
		}
		if($("#content").val()==""){
			alert("input the content");
			$("#content").focus();
			return;
		}
		$("#updateform").submit();
	});
	$("#btn_del").on('click',function(){
		if($("#pwd").val()==""){
			alert("input the password");
			$("#pwd").focus();
			return;
		}
		$("#deleteform").submit();
	});
});

/*
이거 진짜 옛날 키보드네 
컴퓨터실에 있던 그 키보드 느낌
위에 키보드 커버는 도대체 왜 없는거야 
이정도면 분면히 존재해야 할텐데 말이지 허허
*/